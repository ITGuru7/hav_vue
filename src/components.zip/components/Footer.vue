<template>
  <div>
    <div class="bg-primaryColor pt-3 pb-3 primary-txt">
      <v-container grid-list-md text-xs-center >
        <v-layout row wrap>
          <v-flex xs12 md6 pa-3 text-md-left>
            <div class=" avatar--tile ">
              <img src="../assets/logo-kk.png" class="footer-icon" alt="Vuetify">
            </div>
            <p>
              Cvr.: 39368382 <br>
              Tlf.:  23 20 90 43 <br>
            Mail: <a href="mailto:kontakt@kommunekontakt.dk?">kontakt@kommunekontakt.dk</a>
            </p>
          </v-flex>
          <v-flex xs12 md6 pa-3 text-lg-left pl-5>
            <h6>Nyttige links</h6>
            <p>
              <a target="_blank" href="https://www.retsinformation.dk">www.retsinfo.dk</a><br>
              <a target="_blank" href="http://www.star.dk">www.star.dk</a><br>
              <a target="_blank" href="http://www.cabiweb.dk">www.cabiweb.dk</a><br>
              <a target="_blank" href="http://www.jobnet.dk">www.jobnet.dk</a>
            </p>
          </v-flex>
        </v-layout>
        <p class="ml-2" style="font-size: 10px; text-align: left;">By : <a href="http://www.irstha.com" style="text-decoration: none;">IRSTHA</a></p>
      </v-container>
    </div>
  </div>
</template>

<script>
  export default {
    data () {
      return {}
    }
  }
</script>

<style>
</style>

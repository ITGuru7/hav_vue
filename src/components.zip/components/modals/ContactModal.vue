<!--<template>-->
  <!--<div>-->
        <!--<v-dialog v-model="contactM" class="large" persistent width="75%">-->
          <!--<v-card class="bg-primaryColor gray-txt pa-5">-->
            <!--<v-container grid-list-md text-xs-center >-->
              <!--<v-layout row wrap text-lg-center>-->
                <!--<v-flex>-->
                 <!--<h6>SEND MESSAGE</h6>-->
                <!--</v-flex>-->
              <!--</v-layout>-->
                <!--<v-layout row wrap text-lg-left class="pa-3 pb-0">-->
                <!--<v-flex>-->
                  <!--<P class="pt-5">-->
                    <!--<b>Kommunekontackt</b><br>-->
                    <!--Socialgade 13 <br>-->
                    <!--9988 Mentorkøbing <br>-->
                    <!--Tlf.: 007 007 0059 <br>-->
                    <!--Mail: <a href="">kontakt@kommunekontakt.dk</a>-->
                  <!--</P>-->
                <!--</v-flex>-->
                <!--<v-flex>-->
                  <!--<v-text-field box  multi-line placeholder="Discribe ..."></v-text-field>-->
                <!--</v-flex>-->
                <!--</v-layout>-->
              <!--<v-layout row wrap text-md-right pr-0>-->
                <!--<v-flex md1 offset-md9 text-md-right mr-4>-->
                  <!--<v-btn class="bg-kk-btn trans" @click.native="contactM = false">Fortryd</v-btn>-->
                <!--</v-flex>-->
                <!--<v-flex md1>-->
                  <!--<v-btn class="bg-kk-btn" @click.native="contactM = false">send</v-btn>-->
                  <!--<small class="light po-a r-0 mr-5 pr-4">(This message will receive by kommunekontakt team)</small>-->
                <!--</v-flex>-->
              <!--</v-layout>-->
            <!--</v-container>-->
          <!--</v-card>-->
        <!--</v-dialog>-->
  <!--</div>-->
<!--</template>-->
<!--<script>-->
  <!--export default {-->
    <!--props: ['contactM'],-->
    <!--data () {-->
      <!--return {-->
      <!--}-->
    <!--}-->
  <!--}-->
<!--</script>-->

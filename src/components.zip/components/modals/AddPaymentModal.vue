<!--<template>-->
    <!--<div>-->
      <!--<v-dialog v-model="PaymentModal" class="large" persistent width="75%">-->
        <!--<v-card class="bg-white pa-5 kkblue">-->
          <!--<v-container grid-list-md>-->
            <!--<v-layout row wrap>-->
              <!--<v-flex>-->
                <!--<h5>nayanan</h5>-->
              <!--</v-flex>-->
            <!--</v-layout>-->
          <!--</v-container>-->
        <!--</v-card>-->
      <!--</v-dialog>-->
    <!--</div>-->
<!--</template>-->

<!--<script>-->
  <!--export default {-->
    <!--props: ['PaymentModal'],-->
    <!--data () {-->
      <!--return {}-->
    <!--},-->
    <!--components: {}-->
  <!--}-->
<!--</script>-->

<!--<style>-->
<!--</style>-->

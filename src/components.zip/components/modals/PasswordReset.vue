<!--<template>-->
  <!--<div>-->
      <!--<v-dialog v-model="passwordReset" class="large" persistent width="60%">-->
        <!--<v-card class="bg-white pa-5">-->
          <!--<v-container grid-list-md >-->
            <!--<v-layout row wrap text-lg-left>-->
              <!--<v-flex>-->
                <!--<h5>Angiv venligst e-mailadressen der er tilknyttet din brugerkonto. Dit brugernavn vil blive e-mailet til dig.</h5>-->
              <!--</v-flex>-->
            <!--</v-layout>-->
            <!--<v-layout row wrap class=" pl-5">-->
              <!--<v-flex md7 >-->
                <!--<v-text-field-->
                  <!--name="input-1-3"-->
                  <!--placeholder="abc@mail.com"-->
                  <!--type="email"-->
                  <!--single-line-->
                  <!--class="white-bg"-->
                <!--&gt;</v-text-field>-->
              <!--</v-flex>-->
              <!--<v-flex md1 mr-5>-->
                <!--<v-btn class="bg-kk-btn trans" @click.native="passwordReset = false">Fortryd</v-btn>-->
              <!--</v-flex>-->
              <!--<v-flex >-->
                <!--<v-btn class="bg-kk-btn" @click.native="passwordReset = false">send</v-btn>-->
              <!--</v-flex>-->
            <!--</v-layout>-->
          <!--</v-container>-->
        <!--</v-card>-->
      <!--</v-dialog>-->
    <!--</div>-->
<!--</template>-->

<!--<script>-->
  <!--export default {-->
    <!--props: ['passwordReset'],-->
    <!--data () {-->
      <!--return {-->
      <!--}-->
    <!--},-->
    <!--components: {-->
    <!--}-->
  <!--}-->
<!--</script>-->

<!--<style>-->
<!--</style>-->
